<template>
    <nav class="navbar navbar-expand-sm bg-light navbar-light sticky-top shadow">

        <a class="navbar-brand">Healthy Meal</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
            <span class="navbar-toggler-icon"></span>
        </button>


        <div class="collapse navbar-collapse" id="collapsibleNavbar">
            <ul class="navbar-nav">

                <li class="nav-item">
                    <a class="nav-link active" href="#/">Home</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#/Gallery">Gallery</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#/About">About Us</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="OrderOnline.html">Order Online</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="ContactUs.html">Contact Us</a>
                </li>
            </ul>
        </div>

    </nav>
</template>